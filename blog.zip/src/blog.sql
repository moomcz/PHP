/*
Navicat MySQL Data Transfer

Source Server         : node
Source Server Version : 50722
Source Host           : localhost:3306
Source Database       : blog

Target Server Type    : MYSQL
Target Server Version : 50722
File Encoding         : 65001

Date: 2022-06-26 15:48:58
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `user_name` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('123456', 'e10adc3949ba59abbe56e057f20f883e', '1');

-- ----------------------------
-- Table structure for blog
-- ----------------------------
DROP TABLE IF EXISTS `blog`;
CREATE TABLE `blog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `zy` varchar(255) DEFAULT NULL,
  `mail` varchar(255) DEFAULT NULL,
  `scly` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of blog
-- ----------------------------
INSERT INTO `blog` VALUES ('1', '测', '女', '测试', '1850112209@163.com', null);

-- ----------------------------
-- Table structure for category
-- ----------------------------
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of category
-- ----------------------------
INSERT INTO `category` VALUES ('1', '生活随笔');
INSERT INTO `category` VALUES ('2', '技术分享');
INSERT INTO `category` VALUES ('3', '工具分享');
INSERT INTO `category` VALUES ('4', '资源分享');

-- ----------------------------
-- Table structure for comment
-- ----------------------------
DROP TABLE IF EXISTS `comment`;
CREATE TABLE `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` varchar(255) DEFAULT NULL,
  `userName` varchar(255) DEFAULT NULL,
  `time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of comment
-- ----------------------------
INSERT INTO `comment` VALUES ('3', '12', '123456', '2022-06-24 14:55:56');
INSERT INTO `comment` VALUES ('6', '23', 'user123', '2022-06-24 14:55:37');
INSERT INTO `comment` VALUES ('7', '34', 'user123', '2022-06-24 14:55:41');
INSERT INTO `comment` VALUES ('8', '45', 'user122', '2022-06-24 14:55:42');
INSERT INTO `comment` VALUES ('9', '56', 'user122', '2022-06-24 14:55:45');
INSERT INTO `comment` VALUES ('10', '67', '123456', '2022-06-24 14:55:48');
INSERT INTO `comment` VALUES ('11', '123', '123456', '2022-06-23 22:00:59');
INSERT INTO `comment` VALUES ('12', '121', '123456', '2022-06-23 22:01:23');
INSERT INTO `comment` VALUES ('13', '124213124', 'user456', '2022-06-26 14:43:35');

-- ----------------------------
-- Table structure for essay
-- ----------------------------
DROP TABLE IF EXISTS `essay`;
CREATE TABLE `essay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` varchar(11) DEFAULT NULL,
  `content` mediumtext,
  `title` varchar(60) DEFAULT NULL,
  `brief` varchar(255) DEFAULT NULL,
  `time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `like` int(11) DEFAULT '0',
  `collect` int(11) DEFAULT '0',
  `status` int(25) unsigned zerofill DEFAULT '0000000000000000000000000',
  `likeuser` mediumtext,
  `collectuser` mediumtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of essay
-- ----------------------------
INSERT INTO `essay` VALUES ('4', '工具分享', '<p>312123132</p>', '45', '21312', '2022-06-22 23:01:51', '3', '0', '0000000000000000000000001', null, null);
INSERT INTO `essay` VALUES ('5', '工具分享', '<p>324324<strong>324324</strong></p>', '56', '324324', '2022-06-22 23:01:55', '2', '0', '0000000000000000000000001', null, null);
INSERT INTO `essay` VALUES ('6', '工具分享', '<p>312123132</p>', '67', '324324', '2022-06-22 23:01:56', '3', '0', '0000000000000000000000001', null, null);
INSERT INTO `essay` VALUES ('7', '资源分享', '<p>312123132</p>', '78', '324324', '2022-06-22 23:01:57', '3', '0', '0000000000000000000000001', null, null);
INSERT INTO `essay` VALUES ('8', '资源分享', '<p>312123132</p>', '89', '324324', '2022-06-22 23:01:57', '3', '0', '0000000000000000000000001', null, null);
INSERT INTO `essay` VALUES ('10', '资源分享', '<p>312123132</p>', '10', '324324', '2022-06-22 23:01:58', '3', '0', '0000000000000000000000001', null, null);
INSERT INTO `essay` VALUES ('11', '技术分享', '<p>312123132</p>', '11', '324324', '2022-06-22 23:01:59', '3', '0', '0000000000000000000000001', null, null);
INSERT INTO `essay` VALUES ('12', '技术分享', '<p>312123132</p>', '12', '324324', '2022-06-22 23:02:00', '3', '0', '0000000000000000000000001', null, null);
INSERT INTO `essay` VALUES ('13', '技术分享', '<p>123123</p>', '123', '123', '2022-06-22 23:02:00', '0', '0', '0000000000000000000000001', null, null);
INSERT INTO `essay` VALUES ('14', '工具分享', '<p>123</p>', '123', '123', '2022-06-22 23:02:02', '0', '0', '0000000000000000000000001', null, null);
INSERT INTO `essay` VALUES ('15', '工具分享', '<p>123</p>', '123', '123', '2022-06-22 23:02:02', '0', '0', '0000000000000000000000001', null, null);
INSERT INTO `essay` VALUES ('16', '技术分享', '<p>123</p>', '123', '132', '2022-06-22 23:02:03', '0', '0', '0000000000000000000000001', null, null);
INSERT INTO `essay` VALUES ('17', '生活随笔', '<p>123213213123</p>', '1231234', '213214124', '2022-06-23 17:18:50', '1', '1', '0000000000000000000000001', '123456|', '123456|');
INSERT INTO `essay` VALUES ('18', '技术分享', '<p>sadsadad</p>', 'asd', 'asdsad', '2022-06-26 14:54:55', '0', '0', '0000000000000000000000000', null, null);
INSERT INTO `essay` VALUES ('19', '技术分享', '<p><strong>sads</strong></p>', 'asd', 'asdsad', '2022-06-26 14:55:11', '0', '0', '0000000000000000000000000', null, null);
INSERT INTO `essay` VALUES ('21', '生活随笔', '<p style=\"text-align: right;\">阿三打撒打撒打撒阿萨</p>', '测用例', '测试用例', '2022-06-26 15:45:48', '0', '0', '0000000000000000000000001', null, null);

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userName` varchar(20) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', '3366666', 'e10adc3949ba59abbe56e057f20f883e', null);
INSERT INTO `user` VALUES ('2', 'user123', 'fcea920f7412b5da7be0cf42b8c93759', '18650112209');
INSERT INTO `user` VALUES ('3', 'user111', 'fcea920f7412b5da7be0cf42b8c93759', '18650112209');
INSERT INTO `user` VALUES ('4', 'user122', '25f9e794323b453885f5181f1b624d0b', '18650111111');
INSERT INTO `user` VALUES ('5', '123456', 'e10adc3949ba59abbe56e057f20f883e', '18650112209');
INSERT INTO `user` VALUES ('6', '1234563', 'e10adc3949ba59abbe56e057f20f883e', '18650112209');
INSERT INTO `user` VALUES ('7', 'user456', 'e10adc3949ba59abbe56e057f20f883e', '18650112209');
INSERT INTO `user` VALUES ('8', 'user789', 'e10adc3949ba59abbe56e057f20f883e', '18650112209');
