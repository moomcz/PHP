<?php


namespace app\index\controller;


class Essay
{

    public function  getRecommendGoods(){
        $db = db('essay');
        $where = [
            'status' => 1 ,

        ];
        $order = 'time desc';


        $res = $db->where($where)->order($order)->limit(0,12)->select();

        return json($res);
    }

    public  function  getInfo(){
        $id = input('id');
        $where = [
            'status' => 1,
            'id' =>$id
        ];
        $db = db('essay');
        $essay = $db->where($where)->find();
        if ($essay){
            return json($essay);
        }
        return json('获取失败');
    }
    public  function getEssay(){
        $id=input('id');
        $where=['id'=>$id];
        $db=db('essay');
        $essay=$db->where($where)->find();
        if($essay){
            return json([
                "msg"=>'ok',
                "essay"=>$essay
            ]);
        }else{
            return json([
                "msg"=>"err"
            ]);
        }
    }
    public function upState(){
        $post=request()->post();
        $map=[
            $post['key']=>$post['val'],
            trim($post['key1'])=>$post['val1']
        ];
        $where=[
            "id"=>$post['id']
        ];
        $db=db('essay');
        $res=$db->where($where)->update($map);
        if($res){
            $essay=$db->where($where)->find();
            return json([
                "msg"=>"ok",
                "essay"=>$essay
            ]);
        }
        return json(["msg"=>'no']);
    }

}