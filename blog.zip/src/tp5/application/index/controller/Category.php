<?php


namespace app\index\controller;


class Category
{
    public function getList(){
        //获取所有分类数据
        $db = db('category');
        $res = $db->field('id,category_name')->select();
        return json($res);
    }
}