<?php


namespace app\index\controller;


class User
{
    public function reg()
    {
        $user_name = input('userName');
        $password = input('password');
        $password2 = input('password2');
        $phone = input('phone');


        if (empty($user_name)) {
            return json('账号不能为空');
        }

        if (strlen($user_name) < 6 || strlen($user_name) > 20) {
            return json('用户名6--20位');
        }

        if (empty($password)) {
            return json('密码不能为空');
        }

        if (strlen($password) < 6 || strlen($password) > 20) {
            return json('密码6--20位');
        }

        if ($password2 != $password) {
            return json('两次密码不一致');
        }

        $res = '/^1[345678]\d{9}$/';
        if (!preg_match($res, $phone)) {
            return json('手机号码格式不正确');
        }

        $db = db('user');
        $user = $db->field('id')->where('userName', $user_name)->find();

        if ($user) {
            return json('用户名已经被注册');
        }

        $data = [
            'userName' => $user_name,
            'password' => md5($password),
            'phone' => $phone,
        ];


        $res = $db->insert($data);

        if ($res) {
            return json('注册成功');
        }
        return json('注册失败');
    }

    public function login()
    {
        $user_name = input('userName');
        $password = input('password');


        if (empty($user_name)) {
            return json('账号不能为空');
        }

        if (strlen($user_name) < 6 || strlen($user_name) > 20) {
            return json('用户名6--20位');
        }

        if (empty($password)) {
            return json('密码不能为空');
        }

        if (strlen($password) < 6 || strlen($password) > 20) {
            return json('密码6--20位');
        }

        $db = db('user');
        $res = $db->field('id, userName ,password')->where('userName', $user_name)->find();

        if (!$res || md5($password) != $res['password']) {
            return json('用户名不存在或密码错误');

        }
        return json('登录成功');
    }

    public function commentfy()
    {
        $comment = input('comment');
        $username = input('username');


        if (strlen($comment) > 100) {
            return json('评论不能超过100');
        }
        $db = db('comment');

        $data = [
            'comment' => $comment,
            'userName'=>$username,
        ];
        $res = $db->insert($data);
        if ($res) {
            return json('发言成功');
        }
        return json('发言失败');
    }

    public function commentin()
    {
        $db = db('comment');
        $where = [];
        $order = 'time desc';


        $res = $db->where($where)->order($order)->select();

        return json($res);

    }
    public function getblog()
    {
        $db = db('blog');
        $where = [];
        $res = $db->where($where)->select();
        return json($res);

    }
}