<?php


namespace app\admin\controller;


class Admin
{
    public function login(){
        $user_name =input('userName');
        $password = input('password');


        if(empty($user_name)){
            return json('账号不能为空');
        }

        if (strlen($user_name)<6 || strlen($user_name) >20){
            return json('用户名6--20位');
        }

        if(empty($password)){
            return json('密码不能为空');
        }

        if(strlen($password)<6 || strlen($password)>20){
            return  json('密码6--20位');
        }

        $db = db('admin');
        $res = $db->field('id, user_name ,password')->where('user_name',$user_name)->find();

        if (!$res ||md5($password) !=$res['password']){
            return json('用户名不存在或密码错误');

        }
        return json('登录成功');

    }
    public function xiugai(){
        //接受参数
        $name = input('name');
        $mail = input('mail');
        $zy = input('zy');
        $sex = input('sex');


        $db = db('blog');

        $data = [
            'name' => $name,
            'mail' =>$mail,
            'zy' =>$zy,
            'sex' =>$sex,
        ];
        $res = $db->where('id' , '=' ,1)->update($data);

        if ($res){
            return json('添加成功');
        }
        return  json('添加失败');

    }
    public function getblog()
    {
        $db = db('blog');
        $where = [];

        $res = $db->where($where)->select();

        return json($res);

    }

}