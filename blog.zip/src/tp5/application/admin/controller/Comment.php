<?php


namespace app\admin\controller;


class Comment
{
    //删除
    public function de(){
        $id = input('id');
        $db = db('comment');
        $res = $db->where('id',$id)->delete();

        if ($res){
            return json('删除成功');

        }
        return json('删除失败');
    }
    public function getList(){
        $title = input('userName');
        $limit = input('limit');
        $offset = input('offset');
        $where = [];
        if(!empty($title)){
            $where['userName'] = ['like' , '%'.$title.'%'];
        }




        $db = db('comment');
        $res = $db->where($where)->limit($offset, $limit)->select();
        //计算总数量
        $count = $db->where($where)->count();

        //计算总页码
        $total_page = ceil($count / ($limit == 0 ? 1: $limit));
        return json(['list' =>$res , 'pages' => $total_page]);
//        return json($res);
//        echo ($limit);
//        echo ($offset);



    }

    public function commentin()
    {
        $db = db('comment');
        $where = [];
        $order = 'time desc';


        $res = $db->where($where)->order($order)->select();

        return json($res);

    }
}