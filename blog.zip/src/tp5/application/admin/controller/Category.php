<?php


namespace app\admin\controller;


class Category
{
    public function getList(){
        //获取所有分类数据
        $db = db('category');
        $res = $db->field('id,category_name')->select();
        return json($res);
    }

    public function getEssayList(){
        $cid = input('cid');
        $limit = input('limit');
        $offset = input('offset');

        $where = [
            'cid' =>$cid,
            'status' =>1,
        ];

        $order = 'time desc';

        $db = db('essay');

        $list = $db->where($where)->order($order)->limit($offset, $limit)->select();
        $total = $db->where($where)->count();

        return json(['list'=>$list , 'total' =>$total]);
    }
}