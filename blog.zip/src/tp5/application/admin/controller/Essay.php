<?php


namespace app\admin\controller;


class Essay
{
    public function add(){
        //接受参数
        $title = input('title');
        $cid = input('categoryId');
        $brief = input('brief');
//        $cid=\request()->post();
        $content = input('content');
//        return json($cid);
        //数据校验
        if(strlen($title) > 15){
            return json('标题不能超过15');
        }
        if(strlen($brief) > 100){
            return json('文章简介不能超过100');
        }
        if(strlen($cid)<4  || $cid === 0){
            return json('请选择文章分类');
        }
        if(empty($content)){
            return json('文章内容不能为空');
        }
        $db = db('essay');

        $data = [
            'cid' => $cid,
            'title' =>$title,
            'brief' =>$brief,
            'content' =>$content,
            'status'=>0,
        ];
        $res = $db->insert($data);

        if ($res){
            return json('添加成功');
        }
        return  json('添加失败');

    }


    public function getList(){
        $title = input('title');
        $status = input('status');
        $limit = input('limit');
        $offset = input('offset');
        $where = [];
        if(!empty($title)){
            $where['title'] = ['like' , '%'.$title.'%'];
        }

        if(isset($status)  && $status != -1){
            $where['status'] = $status;
        }


        $db = db('essay');
        $field = 'id,title,brief,like,time,status';
        $res = $db->field($field)->where($where)->limit($offset, $limit)->select();
        //计算总数量
        $count = $db->where($where)->count();

        //计算总页码
        $total_page = ceil($count / ($limit == 0 ? 1: $limit));
        return json(['list' =>$res , 'pages' => $total_page]);
//        return json($res);
//        echo ($limit);
//        echo ($offset);



    }

    //发布
    public function fabu(){
        $id = input('id');
        $db = db('essay');
        $res = $db->where('id',$id)->setField('status', 1);

        if ($res){
            return json('发布成功');

        }
        return json('发布失败');
    }

    //删除
    public function de(){
        $id = input('id');
        $db = db('essay');
        $res = $db->where('id',$id)->delete();

        if ($res){
            return json('删除成功');

        }
        return json('删除失败');
    }
    //下架

    public function xiajia(){
        $id = input('id');
        $db = db('essay');
        $res = $db->where('id',$id)->setField('status', 0);

        if ($res){
            return json('撤回成功');

        }
        return json('撤回失败');
    }
    }