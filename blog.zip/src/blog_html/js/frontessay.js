new Vue({		

				data() {
					return{
						essay:{},
						like:{},
						collect:{},
						id:'',
						user:sessionStorage.getItem('user'),
						comment:'',
						username:'',
						commentList:[],
						user:sessionStorage.getItem('user')
					}
				},
				mounted() {
					this._commentin();
					// console.log(this.user)
					if(location.search.indexOf("=")!=-1){
						const id=location.search.split('=')[1];
						this.id=id;
						this.getEssay(id);
					}
				},
				methods:{
					getEssay(id){
						axios.get("http://www.blog.com/index/Essay/getEssay?id="+id).then(res=>{
							if(res.data.msg=='ok'){
								this.essay=res.data.essay;
								console.log(this.essay);
								this.collect=this.getState(this.essay.collectuser);
								this.like=this.getState(this.essay.likeuser);
								console.log(this.like);
							}
						})
					},
					getState(data){
						// console.log(data)
						if(data==null) return {state:false};
						if(data.indexOf('|')!=-1){
							const arr=data.split('|');
							for(var i=0;i<arr.length;i++){
								if(arr[i]==this.user){
									return {state:true,index:i,arr:arr};
								}
							}
						}
						return {state:false};
					},
					send(key,obj){
						let data;
						const key1=key.split('user')[0];
						console.log(obj);
						if(obj.state){
							obj.arr.splice(obj.index,1);
							data={
								key:key,
								key1:key1,
								val1:this.essay[key1]-1,
								val:obj.arr.join("|"),
								id:this.id,
								type:'minus'
							}
						}else{
							if(obj.arr){
								data={
									key:key,
									key1:key1,
									val1:this.essay[key1]+1,
									val:obj.arr.push(this.user).join("|"),
									id:this.id,
									type:'add'
								}
							}else{
								data={
									key:key,
									key1:key1,
									val1:this.essay[key1]+1,
									val:this.user+'|',
									id:this.id,
									type:'add'
								}
							}
						}
						const that=this;
						$.ajax({
							url:'http://www.blog.com/index/Essay/upState',
							method:'post',
							data:data,
							success(data){
								console.log(data)
								that.essay=data.essay;
								that.like=that.getState(data.essay.likeuser)
								that.collect=that.getState(data.essay.collectuser);
							}
						})
					},
					commentout(){
						console.log('点击成功');
						if(this.comment.length > 100){
							return layer.alert('评论不能超过100')
						}
						$.ajax({
							url:'http://www.blog.com/index/User/commentfy',
							dataType:'json',
							type:'post',
							data:{'comment':this.comment,'username':this.user},
							success:(resp) => {
								layer.msg(resp,{icon:1,time:1500});
								if(resp === '发言成功'){
									this.comment=''
									this._commentin();
								}
							}
						})
					},
					_commentin(){
						$.ajax({
							url:'http://www.blog.com/index/User/commentin',
							dataType:'json',
							success: (resp) =>{
								this.commentList = resp;
							}
						})
					}
				}
			}).$mount('#app');