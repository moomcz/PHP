//头部组件
Vue.component('bk-heater',{
	template:`<div id="header">
				<div class="container">
					<div class="warp">
						<div class="welcome">
							欢迎光临xxx博客
						</div>
						<div class="link">
							<a href="login.html">登入</a>
							<a href="reg.html">注册</a>
						</div>
					</div>

				</div>

			</div>`
})
//logo组件
Vue.component('bk-logo',{
	template:`<div id="logo-box" class="container">
				<div class="logo">
					<img src="../image/logo3.png" alt="">
				</div>
				<div class="search-box">
					<div class="input-group">
						<input class="form-control" />
						<span class="input-group-addon">
							<span class="glyphicon glyphicon-search"></span>
						</span>
					</div>
				</div>
			</div>`
})
//导航条组件
Vue.component('bk-nav',{
	data(){
		return{
			categoryList:[],
		}
	},
	mounted(){
		this._getCategoryList();
	},
	methods:{
		_getCategoryList(){
			let that = this;
			$.ajax({
				url:'http://www.blog.com/index/Category/getList',
				dataType:'json',
				success(resp){
					that.categoryList = resp;
				}
			})
		}
	},
	template:``
})

//底部组件
Vue.component('bk-footer',{
	template:`<div id="footer">
				版权所有&copy;fx2011
			</div>`
})



