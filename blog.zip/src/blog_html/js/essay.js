new Vue({
		
		data(){
			return{
				essayInfo:{
					title:'',
					brief:'',
					categoryId:0,
					content:'',
				},
				
				categoryList:[],
				id:'',
				limit:5,		//每页两条数据
				currentPage:1,	//当前页第一页
				essayList:[],	//文章列表
				pages:0,		//总页码
				searchKeyword:'',
				searchStatus:'',
				
				sendKeyword:'',
				sendStatus:-1,
			}
		},	
			
			
			mounted(){
				this._getCategory();
				this._initW(); 
				this._getEssayList();
			},
			
			methods:{
				search(){
					this.sendKeyword = this.searchKeyword;
					this.sendStatus = this.searchStatus;
					this.currentPage = 1;
					this._getEssayList();
				},
				
				//上一页
				prev(){
					if(this.currentPage <= 1){
						return layer.alert('已经是第一页了');
					}
					this.currentPage--
					this._getEssayList();
				},
				//下一页
				next(){
					if(this.currentPage >= this.pages){
						return layer.alert('已经是最后一页了');
					}
					this.currentPage++
					this._getEssayList();
				},
				
				
				//发布
				fabu(id){
					let that = this;
					layer.confirm('是否发布这篇文章',function(){
						$.ajax({
							url:'http://www.blog.com/admin/Essay/fabu',
							data:{id:id},
							type:'POST',
							dataType:'json',
							success(resp){
								layer.alert(resp);
								if(resp === '发布成功'){
									that._getEssayList();
								}
							}
						})
					});
					
				},
				//下架
				xiajia(id){
					let that = this;
					layer.confirm('是否撤回这篇文章',function(){
						$.ajax({
							url:'http://www.blog.com/admin/Essay/xiajia',
							data:{id:id},
							type:'POST',
							dataType:'json',
							success(resp){
								layer.alert(resp);
								if(resp === '撤回成功'){
									that._getEssayList();
								}
							}
						})
					});
				},
				//删除
				de(id){
					let that = this;
					layer.confirm('是否删除这篇文章',function(){
						$.ajax({
							url:'http://www.blog.com/admin/Essay/de',
							data:{id:id},
							type:'POST',
							dataType:'json',
							success(resp){
								layer.alert(resp);
								if(resp === '删除成功'){
									that._getEssayList();
								}
							}
						})
					});
				},
				
				
				_initW(){
					let that = this;
					//【注意】下面使用的 typescript 语法。如用 javascript 语法，把类型去掉即可。
					
					// 编辑器配置
					const editorConfig= {}
					editorConfig.placeholder = '请输入内容'
					editorConfig.onChange = (editor) => {
					    // 把富文本编辑器的值赋值给  内容
						that.essayInfo.content = editor.getHtml();
					}
					
					// 工具栏配置
					const toolbarConfig= {}
					
					// 创建编辑器
					const editor = wangEditor.createEditor({
					  selector: '#editor-container',
					  config: editorConfig,
					  mode: 'default' // 或 'simple' 参考下文
					})
					// 创建工具栏
					const toolbar = wangEditor.createToolbar({
					  editor,
					  selector: '#toolbar-container',
					  config: toolbarConfig,
					  mode: 'default' // 或 'simple' 参考下文
					})
								
				},
				
				//获取分类列表
				_getCategory(){
					let that = this;
					console.log(1);

					axios.get("http://www.blog.com/admin/Category/getList").then(res=>{
						this.categoryList = res.data;
					})
				},
				
				
				submit(){
					console.log('确认添加');
					console.log(this.essayInfo)
					
					//数据合法性校验
					let e = this.essayInfo;
					if(e.title.length > 15){
						return layer.alert('标题不能超过15')
					}
					if(!e.brief.length > 100){
						return layer.alert('文章简介不能超过100')
					}
					if(!e.categoryId  || e.categoryId === 0){
						return layer.alert('请选择文章分类')
					}
					if(!e.content){
						return layer.alert('文章内容不能为空')
					}
					//ajax
					console.log(this.essayInfo)
					axios({
						url:'http://www.blog.com/admin/Essay/add',
						dataType:'json',
						method:'post',
						data:this.essayInfo,
						
					}).then(function(resp){
						// console.log(resp)
							layer.alert(resp.data,function(){
								if(resp.data === '添加成功'){
									$('#add-box').modal('hide');
									layer.closeAll();
								}
							})
						})
					
					
				},
				
				//获取商品列表
				_getEssayList(){
					let that = this;
					// console.log(this.limit);
					$.ajax({
						url:'http://www.blog.com/admin/Essay/getList',
						dataType:'json',
						type:'GET',
						data:{
							title:this.sendKeyword,
							status:this.sendStatus,
							limit:this.limit,
							offset: (this.currentPage - 1) * this.limit,
						},
						success(resp){
							that.essayList = resp.list;
							that.pages = resp.pages;
							
						}
					})
				},
				
				
				
			
			}
			
			
			
		}).$mount('#app');