new Vue({
	data(){
		return{
			essayInfo:{
				name:'',
				sex:'男',
				zy:'',
				mail:'',
			}
			
		}
	},
	
	mounted(){
		this._getblog();
	},
	methods:{
		submit(){
			console.log('123');
			//ajax
			axios({
				url:'http://www.blog.com/admin/Admin/xiugai',
				dataType:'json',
				method:'post',
				data:this.essayInfo,
				
			}).then(function(resp){
					layer.alert(resp.data,function(){
						if(resp.data === '修改成功'){
							$('#add-box').modal('hide');
							layer.closeAll();
						}
					})
				})
			
			
		},
		_getblog(){
			$.ajax({
				url:'http://www.blog.com/admin/Admin/getblog',
				dataType:'json',
				data:this.essayInfo,
				success: (resp) => {
					this.essayInfo = resp[0];
				}
			})
		}
	}
}).$mount('#app')