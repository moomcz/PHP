new Vue({

	data() {
		return {
			essayInfo: {
				title: '',
				brief: '',
				categoryId: 0,
				content: '',
			},

			categoryList: [],
			id: '',
			limit: 5, //每页两条数据
			currentPage: 1, //当前页第一页
			essayList: [], //文章列表
			pages: 0, //总页码
			searchKeyword: '',
			searchStatus: '',
			commentList: [],
			sendKeyword: '',
			sendStatus: -1,
		}
	},


	mounted() {
		this._comment();

	},


	methods: {
		search() {
			this.sendKeyword = this.searchKeyword;
			this.sendStatus = this.searchStatus;
			this.currentPage = 1;
			this._comment();
		},
		//上一页
		prev() {
			if (this.currentPage <= 1) {
				return layer.alert('已经是第一页了');
			}
			this.currentPage--
			this._comment();
		},
		//下一页
		next() {
			if (this.currentPage >= this.pages) {
				return layer.alert('已经是最后一页了');
			}
			this.currentPage++
			this._comment();
		},
		_comment() {
			$.ajax({
				url: 'http://www.blog.com/admin/Comment/getList',
				dataType: 'json',
				data:{
					userName:this.sendKeyword,
					limit:this.limit,
					offset: (this.currentPage - 1) * this.limit,
				},
				success: (resp) => {
					this.commentList = resp.list;
					this.pages = resp.pages;
				}
			})
		},
		//删除
		del(id) {
			let that = this;
			layer.confirm('是否删除这篇文章', function() {
				$.ajax({
					url: 'http://www.blog.com/admin/Comment/de',
					data: {
						id: id
					},
					type: 'POST',
					dataType: 'json',
					success(resp) {
						layer.alert(resp);
						if (resp === '删除成功') {
							that._comment();
						}
					}
				})
			});
		}
	},
	



}).$mount('#app');
