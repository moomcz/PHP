new Vue({
	data(){
		return{
			essayList:[],
			essay:[],
			categoryList:['生活随笔','技术分享','工具分享','资源分享'],
			blogList:{}
			
			
			
		}
	},
	
	mounted(){
		this._getEssayList();
		this._getblog();
	},
	methods:{
		_getEssayList(){
			$.ajax({
				url:'http://www.blog.com/index/Essay/getRecommendGoods',
				dataType:'json',
				success: resp => {
					this.essayList = resp;
					this.essay=resp;
				}
			})
		},
		fenlei(key){
			if(key=='home'){
				this.essay=this.essayList;
			}else{
				console.log(key)
				const arr=[...this.essayList];//数组克隆
				this.essay=arr.filter(a=>a['cid']==key);//过滤器
			}
		},
		go(id){
			window.location.href="./essay.html?id="+id
		},
		_getblog(){
			$.ajax({
				url:'http://www.blog.com/index/User/getblog',
				dataType:'json',
				success: resp => {
					this.blogList = resp[0];

				}
			})
		},
	}
}).$mount('#app')